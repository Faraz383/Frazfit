import React,{useCallback,useState} from 'react';
import {Pressable,ScrollView,StyleSheet,Text,TextInput,View} from 'react-native';
import {useFocusEffect} from 'expo-router';
import {ScreenHeader} from '@/components/ScreenHeader';
import {GlassCard} from '@/components/GlassCard';
import {addMeasurement,getMeasurementHistory,Measurement} from '@/db/database';
import {colors} from '@/theme/colors';

export default function Measurements(){
 const[waist,setWaist]=useState('');const[chest,setChest]=useState('');const[arm,setArm]=useState('');const[history,setHistory]=useState<Measurement[]>([]);
 const load=useCallback(()=>{getMeasurementHistory().then(setHistory)},[]);useFocusEffect(useCallback(()=>{load()},[load]));
 const save=async()=>{await addMeasurement({waistCm:Number(waist)||undefined,chestCm:Number(chest)||undefined,armCm:Number(arm)||undefined});setWaist('');setChest('');setArm('');load()};
 return <ScrollView style={styles.screen} contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled"><ScreenHeader title="Body measurements" subtitle="Tape measurements ko same conditions mein repeat karein"/><GlassCard glow><View style={styles.form}><Measure label="Waist" value={waist} set={setWaist}/><Measure label="Chest" value={chest} set={setChest}/><Measure label="Arm" value={arm} set={setArm}/><Pressable style={styles.save} onPress={save}><Text style={styles.saveText}>Save measurements</Text></Pressable></View></GlassCard><Text style={styles.section}>History</Text>{history.length===0?<Text style={styles.empty}>No measurements logged yet.</Text>:history.map(x=><GlassCard key={x.id} style={{marginBottom:8}}><View style={styles.row}><View><Text style={styles.date}>{x.date}</Text><Text style={styles.values}>Waist {x.waistCm??'—'} · Chest {x.chestCm??'—'} · Arm {x.armCm??'—'} cm</Text></View></View></GlassCard>)}</ScrollView>
}
function Measure({label,value,set}:{label:string;value:string;set:(v:string)=>void}){return <View style={styles.measure}><Text style={styles.label}>{label}</Text><TextInput value={value} onChangeText={set} keyboardType="decimal-pad" placeholder="cm" placeholderTextColor={colors.textDim} style={styles.input}/></View>}
const styles=StyleSheet.create({screen:{flex:1,backgroundColor:colors.bg},content:{paddingTop:54,paddingHorizontal:18,paddingBottom:44},form:{padding:18},measure:{marginBottom:12},label:{color:colors.textMuted,fontSize:10,fontWeight:'800',marginBottom:6},input:{height:50,borderRadius:24,paddingHorizontal:16,color:colors.white,fontSize:17,fontWeight:'800',backgroundColor:'rgba(255,255,255,.06)',borderWidth:1,borderColor:'rgba(255,255,255,.12)'},save:{marginTop:6,padding:16,borderRadius:999,backgroundColor:colors.lime,alignItems:'center'},saveText:{color:colors.dark,fontWeight:'900'},section:{color:colors.white,fontSize:17,fontWeight:'900',marginTop:24,marginBottom:10},empty:{color:colors.textDim,fontSize:11},row:{padding:15},date:{color:colors.white,fontWeight:'900',fontSize:13},values:{color:colors.textMuted,fontSize:10.5,marginTop:4}})
