import React, { useEffect, useState } from 'react';
import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { View, ActivityIndicator } from 'react-native';
import { initDatabase } from '@/db/database';
import { colors } from '@/theme/colors';

export default function RootLayout(){
  const [ready,setReady]=useState(false);
  useEffect(()=>{initDatabase().finally(()=>setReady(true))},[]);
  if(!ready)return <View style={{flex:1,backgroundColor:colors.bg,alignItems:'center',justifyContent:'center'}}><ActivityIndicator color={colors.lime}/></View>;
  return <>
    <StatusBar style="light"/>
    <Stack screenOptions={{headerShown:false,contentStyle:{backgroundColor:colors.bg},animation:'fade_from_bottom'}}>
      <Stack.Screen name="(tabs)"/>
      <Stack.Screen name="add-food"/>
      <Stack.Screen name="scan"/>
      <Stack.Screen name="food-photo"/>
      <Stack.Screen name="custom-food"/>
      <Stack.Screen name="exercise/[id]"/>
      <Stack.Screen name="routine"/>
      <Stack.Screen name="walk"/>
      <Stack.Screen name="fasting"/>
      <Stack.Screen name="measurements"/>
      <Stack.Screen name="photos"/>
      <Stack.Screen name="profile-settings"/>
      <Stack.Screen name="online-food"/>
      <Stack.Screen name="exercise-discover"/>
    </Stack>
  </>;
}
