import React,{useEffect,useState} from 'react';
import {ActivityIndicator,Image,Pressable,ScrollView,StyleSheet,Text,TextInput,View} from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import {useRouter} from 'expo-router';
import {ScreenHeader} from '@/components/ScreenHeader';
import {GlassCard} from '@/components/GlassCard';
import {Food,getFoods} from '@/db/database';
import {colors} from '@/theme/colors';

let ImageLabeling:any=null;
try{ImageLabeling=require('@react-native-ml-kit/image-labeling').default}catch{}

export default function FoodPhoto(){
 const router=useRouter();const[uri,setUri]=useState('');const[labels,setLabels]=useState<string[]>([]);const[q,setQ]=useState('');const[foods,setFoods]=useState<Food[]>([]);const[busy,setBusy]=useState(false);const[msg,setMsg]=useState('Photo scan on-device labels use karta hai. Final calories se pehle food aur portion aap confirm karenge.');
 useEffect(()=>{if(q.trim())getFoods(q).then(setFoods);else setFoods([])},[q]);
 const capture=async()=>{const perm=await ImagePicker.requestCameraPermissionsAsync();if(!perm.granted){setMsg('Camera permission required.');return;}const r=await ImagePicker.launchCameraAsync({quality:.72});if(r.canceled)return;const imageUri=r.assets[0].uri;setUri(imageUri);setBusy(true);setLabels([]);try{if(ImageLabeling){const result=await ImageLabeling.label(imageUri);const names=(result||[]).map((x:any)=>String(x.text||x.label||'')).filter(Boolean).slice(0,6);setLabels(names);const useful=names.find((x:string)=>!['food','dish','meal','cuisine'].includes(x.toLowerCase()));if(useful)setQ(useful);setMsg(names.length?'On-device labels mil gaye. Neeche correct food select ya search karein.':'Food automatically identify nahi hua. Manual search use karein.')}else setMsg('On-device image-labeling module is build mein available nahi. Manual confirmation use karein.')}catch{setMsg('Image labeling fail hui. Manual search se food confirm karein.')}finally{setBusy(false)}};
 return <ScrollView style={styles.screen} contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled"><ScreenHeader title="Food photo" subtitle="Free on-device recognition + manual confirmation"/>
   {!uri?<Pressable style={styles.camera} onPress={capture}><Text style={styles.cameraIcon}>◎</Text><Text style={styles.cameraTitle}>Take meal photo</Text><Text style={styles.cameraSub}>No photo is uploaded to a paid cloud service.</Text></Pressable>:<><Image source={{uri}} style={styles.image}/><Pressable style={styles.retake} onPress={capture}><Text style={styles.retakeText}>Retake photo</Text></Pressable></>}
   {busy?<ActivityIndicator color={colors.lime} style={{marginTop:18}}/>:null}
   {labels.length?<View style={styles.chips}>{labels.map(x=><Pressable key={x} style={styles.chip} onPress={()=>setQ(x)}><Text style={styles.chipText}>{x}</Text></Pressable>)}</View>:null}
   <Text style={styles.msg}>{msg}</Text>
   <TextInput value={q} onChangeText={setQ} placeholder="Confirm/search food e.g. biryani" placeholderTextColor={colors.textDim} style={styles.search}/>
   {foods.map(f=><Pressable key={f.id} onPress={()=>router.replace({pathname:'/add-food',params:{query:f.name}})}><GlassCard style={{marginTop:9}}><View style={styles.row}><View style={{flex:1}}><Text style={styles.name}>{f.name}</Text><Text style={styles.sub}>{f.servingLabel} · P {f.protein.toFixed(1)}g</Text></View><Text style={styles.cal}>{Math.round(f.calories)} kcal</Text></View></GlassCard></Pressable>)}
   <Text style={styles.note}>Camera food recognition exact calories nahi jaan sakti, khas taur par ghar ke khane mein oil/ghee unknown hota hai. FrazFit is liye confirmation mangta hai.</Text>
 </ScrollView>
}
const styles=StyleSheet.create({screen:{flex:1,backgroundColor:colors.bg},content:{paddingTop:54,paddingHorizontal:18,paddingBottom:44},camera:{height:250,borderRadius:34,backgroundColor:'rgba(39,45,41,.48)',borderWidth:1,borderColor:colors.border,alignItems:'center',justifyContent:'center'},cameraIcon:{fontSize:52,color:colors.lime},cameraTitle:{color:colors.white,fontSize:19,fontWeight:'900',marginTop:8},cameraSub:{color:colors.textMuted,fontSize:10.5,marginTop:5},image:{width:'100%',height:280,borderRadius:34,backgroundColor:'#333'},retake:{alignSelf:'center',marginTop:9,paddingHorizontal:18,paddingVertical:10,borderRadius:999,backgroundColor:'rgba(255,255,255,.09)'},retakeText:{color:colors.white,fontSize:11,fontWeight:'900'},chips:{flexDirection:'row',flexWrap:'wrap',gap:7,marginTop:15},chip:{paddingHorizontal:12,paddingVertical:8,borderRadius:999,backgroundColor:'rgba(183,255,0,.12)',borderWidth:1,borderColor:'rgba(183,255,0,.3)'},chipText:{color:colors.lime,fontSize:10,fontWeight:'800'},msg:{color:colors.textMuted,fontSize:10.5,lineHeight:16,textAlign:'center',marginTop:14},search:{height:54,borderRadius:27,paddingHorizontal:16,color:colors.white,backgroundColor:'rgba(39,45,41,.45)',borderWidth:1,borderColor:colors.border,marginTop:14},row:{padding:15,flexDirection:'row',alignItems:'center',gap:9},name:{color:colors.white,fontSize:13.5,fontWeight:'900'},sub:{color:colors.textMuted,fontSize:10.5,marginTop:4},cal:{color:colors.lime,fontWeight:'900'},note:{color:colors.textDim,fontSize:10.5,lineHeight:16,textAlign:'center',marginTop:18}})
