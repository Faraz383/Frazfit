import React,{useCallback,useState} from 'react';
import {Alert,Pressable,ScrollView,StyleSheet,Text,View} from 'react-native';
import {useFocusEffect,useRouter} from 'expo-router';
import {GlassCard} from '@/components/GlassCard';
import {createBackup,restoreBackup} from '@/services/backup';
import {cancelAllFrazFitReminders,scheduleDailyWaterReminder,scheduleDailyWeightReminder,scheduleDailyWorkoutReminder} from '@/services/reminders';
import {getProfile,Profile} from '@/db/database';
import {colors} from '@/theme/colors';

export default function Settings(){
 const router=useRouter(); const[busy,setBusy]=useState(''); const[profile,setProfile]=useState<Profile|null>(null);
 useFocusEffect(useCallback(()=>{getProfile().then(setProfile)},[]));
 const action=async(type:string,fn:()=>Promise<any>,success:string)=>{try{setBusy(type);await fn();Alert.alert('FrazFit',success)}catch(e:any){Alert.alert('FrazFit',e?.message||'Something went wrong.')}finally{setBusy('')}};
 return <ScrollView style={styles.screen} contentContainerStyle={styles.content}>
   <Text style={styles.eyebrow}>PERSONAL CONTROL</Text><Text style={styles.title}>More</Text>
   <GlassCard glow style={{marginTop:18}}><Pressable style={styles.profile} onPress={()=>router.push('/profile-settings')}><View style={styles.avatar}><Text style={styles.avatarText}>F</Text></View><View style={{flex:1}}><Text style={styles.profileTitle}>My FrazFit profile</Text><Text style={styles.profileSub}>{profile?`${profile.currentWeight.toFixed(1)} kg · target ${profile.targetWeight.toFixed(0)} kg · ${profile.fitnessLevel}`:'Loading...'}</Text></View><Text style={styles.arrow}>›</Text></Pressable></GlassCard>
   <Text style={styles.section}>Tracking tools</Text>
   <Item icon="◷" title="Fasting tracker" sub="Start, stop and review fasting sessions" onPress={()=>router.push('/fasting')}/>
   <Item icon="⌁" title="Walking tracker" sub="GPS distance, time and estimated burn" onPress={()=>router.push('/walk')}/>
   <Item icon="◎" title="Body measurements" sub="Waist, chest and arm logs" onPress={()=>router.push('/measurements')}/>
   <Item icon="▧" title="Progress photos" sub="Private photos stored on your phone" onPress={()=>router.push('/photos')}/>
   <Text style={styles.section}>Data & reminders</Text>
   <Item icon="⇧" title={busy==='backup'?'Preparing backup…':'Create backup'} sub="Export your local FrazFit data as JSON" onPress={()=>action('backup',createBackup,'Backup file is ready to save/share.')}/>
   <Item icon="⇩" title={busy==='restore'?'Restoring…':'Restore backup'} sub="Import a previous FrazFit backup" onPress={()=>action('restore',restoreBackup,'Backup restored. Reopen screens to refresh data.')}/>
   <Item icon="◉" title="Daily hydration reminder" sub="Local 10:00 reminder" onPress={()=>action('water-reminder',()=>scheduleDailyWaterReminder(10,0),'Daily hydration reminder is enabled.')}/><Item icon="↗" title="Morning weigh-in reminder" sub="Local 07:00 reminder" onPress={()=>action('weight-reminder',()=>scheduleDailyWeightReminder(7,0),'Morning weigh-in reminder is enabled.')}/><Item icon="✦" title="Evening movement reminder" sub="Local 18:00 reminder" onPress={()=>action('workout-reminder',()=>scheduleDailyWorkoutReminder(18,0),'Evening movement reminder is enabled.')}/><Item icon="×" title="Clear all reminders" sub="Remove FrazFit scheduled notifications" onPress={()=>action('clear-reminders',cancelAllFrazFitReminders,'Scheduled reminders cleared.')}/>
   <Text style={styles.section}>Free data sources</Text>
   <GlassCard><View style={styles.info}><Text style={styles.infoTitle}>No paid API dependency</Text><Text style={styles.infoText}>Barcode nutrition uses Open Food Facts. Exercise discovery can use the public wger API. Core tracking remains local and works without an account.</Text></View></GlassCard>
   <Text style={styles.version}>FrazFit · local-first fitness companion · v1.0</Text>
 </ScrollView>
}
function Item({icon,title,sub,onPress}:{icon:string;title:string;sub:string;onPress:()=>void}){return <Pressable onPress={onPress}><GlassCard style={{marginBottom:9}}><View style={styles.item}><View style={styles.icon}><Text style={styles.iconText}>{icon}</Text></View><View style={{flex:1}}><Text style={styles.itemTitle}>{title}</Text><Text style={styles.itemSub}>{sub}</Text></View><Text style={styles.itemArrow}>›</Text></View></GlassCard></Pressable>}
const styles=StyleSheet.create({screen:{flex:1,backgroundColor:colors.bg},content:{paddingTop:58,paddingHorizontal:18,paddingBottom:120},eyebrow:{color:colors.lime,fontSize:12,fontWeight:'900',letterSpacing:2},title:{color:colors.white,fontSize:31,fontWeight:'900',marginTop:4},profile:{padding:18,flexDirection:'row',alignItems:'center',gap:13},avatar:{width:56,height:56,borderRadius:28,backgroundColor:colors.lime,alignItems:'center',justifyContent:'center'},avatarText:{color:colors.dark,fontSize:21,fontWeight:'900'},profileTitle:{color:colors.white,fontSize:16,fontWeight:'900'},profileSub:{color:colors.textMuted,fontSize:10.5,marginTop:4},arrow:{color:colors.lime,fontSize:29},section:{color:colors.white,fontSize:17,fontWeight:'900',marginTop:24,marginBottom:10},item:{padding:14,flexDirection:'row',alignItems:'center',gap:12},icon:{width:43,height:43,borderRadius:17,backgroundColor:'rgba(183,255,0,.12)',alignItems:'center',justifyContent:'center'},iconText:{color:colors.lime,fontSize:19,fontWeight:'900'},itemTitle:{color:colors.white,fontSize:13.5,fontWeight:'900'},itemSub:{color:colors.textMuted,fontSize:10.5,marginTop:3},itemArrow:{color:colors.textMuted,fontSize:26},info:{padding:18},infoTitle:{color:colors.white,fontSize:14,fontWeight:'900'},infoText:{color:colors.textMuted,fontSize:11,lineHeight:17,marginTop:6},version:{color:colors.textDim,fontSize:10,textAlign:'center',marginTop:24}})
