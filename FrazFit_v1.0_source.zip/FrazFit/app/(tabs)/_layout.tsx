import React from 'react';
import { Tabs } from 'expo-router';
import { Text } from 'react-native';
import { colors } from '@/theme/colors';

const Icon=({emoji,focused}:{emoji:string;focused:boolean})=><Text style={{fontSize:focused?23:20,opacity:focused?1:.62,color:focused?colors.lime:colors.textDim}}>{emoji}</Text>;

export default function TabLayout(){
 return <Tabs screenOptions={{
   headerShown:false,
   sceneStyle:{backgroundColor:colors.bg},
   tabBarStyle:{position:'absolute',left:12,right:12,bottom:12,height:72,borderRadius:26,paddingTop:6,paddingBottom:9,backgroundColor:'rgba(35,42,38,.97)',borderTopWidth:0,borderWidth:1,borderColor:'rgba(255,255,255,.13)',elevation:16},
   tabBarLabelStyle:{fontSize:9,fontWeight:'800'},tabBarActiveTintColor:colors.lime,tabBarInactiveTintColor:colors.textDim
 }}>
   <Tabs.Screen name="index" options={{title:'Home',tabBarIcon:({focused})=><Icon emoji="⌂" focused={focused}/>}}/>
   <Tabs.Screen name="food" options={{title:'Nutrition',tabBarIcon:({focused})=><Icon emoji="◉" focused={focused}/>}}/>
   <Tabs.Screen name="workouts" options={{title:'Training',tabBarIcon:({focused})=><Icon emoji="✦" focused={focused}/>}}/>
   <Tabs.Screen name="progress" options={{title:'Progress',tabBarIcon:({focused})=><Icon emoji="↗" focused={focused}/>}}/>
   <Tabs.Screen name="settings" options={{title:'More',tabBarIcon:({focused})=><Icon emoji="•••" focused={focused}/>}}/>
 </Tabs>
}
