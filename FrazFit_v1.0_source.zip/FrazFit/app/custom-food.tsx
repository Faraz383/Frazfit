import React,{useState} from 'react';
import {Alert,ScrollView,StyleSheet,Text,TextInput} from 'react-native';
import {useRouter} from 'expo-router';
import {ScreenHeader} from '@/components/ScreenHeader';
import {NeoButton} from '@/components/NeoButton';
import {GlassCard} from '@/components/GlassCard';
import {addCustomFood} from '@/db/database';
import {colors} from '@/theme/colors';

export default function CustomFood(){
 const router=useRouter(); const[name,setName]=useState('');const[serving,setServing]=useState('100 g');const[grams,setGrams]=useState('100');const[cal,setCal]=useState('');const[p,setP]=useState('');const[c,setC]=useState('');const[f,setF]=useState('');
 const save=async()=>{if(!name.trim()||!(Number(cal)>=0)){Alert.alert('FrazFit','Food name aur calories enter karein.');return;}await addCustomFood({name:name.trim(),servingLabel:serving.trim()||'1 serving',servingGrams:Number(grams)||100,calories:Number(cal)||0,protein:Number(p)||0,carbs:Number(c)||0,fat:Number(f)||0,category:'custom'});Alert.alert('FrazFit','Custom food save ho gaya.');router.back()};
 return <ScrollView style={styles.screen} contentContainerStyle={styles.content}><ScreenHeader title="Custom food" subtitle="Apne ghar ke meal ya recipe ko save karein"/><GlassCard><Text style={styles.label}>Food name</Text><Field value={name} set={setName} placeholder="e.g. Ammi ki chicken curry"/><Text style={styles.label}>Serving label</Text><Field value={serving} set={setServing}/><Text style={styles.label}>Serving grams</Text><Field value={grams} set={setGrams} numeric/><Text style={styles.label}>Calories per serving</Text><Field value={cal} set={setCal} numeric/><Text style={styles.label}>Protein (g)</Text><Field value={p} set={setP} numeric/><Text style={styles.label}>Carbs (g)</Text><Field value={c} set={setC} numeric/><Text style={styles.label}>Fat (g)</Text><Field value={f} set={setF} numeric/><NeoButton label="Save custom food" onPress={save} style={{marginTop:18}}/></GlassCard><Text style={styles.note}>Recipe calories tab best hoti hain jab ingredients aur oil ki quantity measure ki jaye.</Text></ScrollView>
}
function Field({value,set,placeholder,numeric=false}:{value:string;set:(v:string)=>void;placeholder?:string;numeric?:boolean}){return <TextInput value={value} onChangeText={set} placeholder={placeholder} placeholderTextColor={colors.textDim} keyboardType={numeric?'decimal-pad':'default'} style={styles.input}/>}
const styles=StyleSheet.create({screen:{flex:1,backgroundColor:colors.bg},content:{paddingTop:54,paddingHorizontal:18,paddingBottom:44},label:{color:colors.textMuted,fontSize:10,fontWeight:'800',marginTop:14,marginBottom:6,paddingHorizontal:18},input:{marginHorizontal:14,height:50,borderRadius:23,paddingHorizontal:16,color:colors.white,backgroundColor:'rgba(255,255,255,.06)',borderWidth:1,borderColor:'rgba(255,255,255,.12)'},note:{color:colors.textDim,fontSize:10.5,lineHeight:16,textAlign:'center',marginTop:16}})
