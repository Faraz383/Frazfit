import React, { useRef, useState } from 'react';
import { ActivityIndicator, Pressable, StyleSheet, Text, View } from 'react-native';
import { CameraView, useCameraPermissions } from 'expo-camera';
import { useRouter } from 'expo-router';
import { lookupBarcode } from '@/services/openFoodFacts';
import { colors } from '@/theme/colors';

export default function ScanScreen(){
  const router=useRouter();
  const [permission,requestPermission]=useCameraPermissions();
  const [busy,setBusy]=useState(false);
  const lock=useRef(false);
  if(!permission)return <View style={styles.screen}/>;
  if(!permission.granted)return <View style={styles.permission}><Text style={styles.title}>Camera permission</Text><Text style={styles.desc}>FrazFit needs camera access only to scan food barcodes.</Text><Pressable style={styles.button} onPress={requestPermission}><Text style={styles.buttonText}>Allow camera</Text></Pressable><Pressable onPress={()=>router.back()}><Text style={styles.cancel}>Cancel</Text></Pressable></View>;
  const scanned=async({data}:{data:string})=>{
    if(lock.current)return; lock.current=true; setBusy(true);
    try{
      const product=await lookupBarcode(data);
      if(product) router.replace({pathname:'/add-food',params:{product:JSON.stringify(product)}});
      else { lock.current=false; setBusy(false); }
    }catch{ lock.current=false; setBusy(false); }
  };
  return <View style={styles.screen}><CameraView style={StyleSheet.absoluteFill} facing="back" barcodeScannerSettings={{barcodeTypes:['ean13','ean8','upc_a','upc_e']}} onBarcodeScanned={scanned}/><View style={styles.overlay}><View style={styles.top}><Pressable style={styles.back} onPress={()=>router.back()}><Text style={styles.backText}>‹</Text></Pressable><Text style={styles.scanTitle}>Scan food barcode</Text><View style={{width:46}}/></View><View style={styles.frame}><View style={[styles.corner,styles.tl]}/><View style={[styles.corner,styles.tr]}/><View style={[styles.corner,styles.bl]}/><View style={[styles.corner,styles.br]}/></View><View style={styles.help}>{busy?<><ActivityIndicator color={colors.lime}/><Text style={styles.helpText}>Checking free food database…</Text></>:<Text style={styles.helpText}>Place EAN/UPC barcode inside the frame</Text>}</View></View></View>
}
const styles=StyleSheet.create({screen:{flex:1,backgroundColor:'#111'},permission:{flex:1,backgroundColor:colors.bg,padding:28,alignItems:'center',justifyContent:'center'},title:{color:colors.white,fontSize:25,fontWeight:'900'},desc:{color:colors.textMuted,textAlign:'center',marginTop:10,lineHeight:20},button:{backgroundColor:colors.lime,paddingHorizontal:24,paddingVertical:14,borderRadius:999,marginTop:24},buttonText:{color:colors.dark,fontWeight:'900'},cancel:{color:colors.white,marginTop:18},overlay:{flex:1,backgroundColor:'rgba(0,0,0,.16)',paddingTop:54,paddingHorizontal:18,justifyContent:'space-between',paddingBottom:55},top:{flexDirection:'row',alignItems:'center',justifyContent:'space-between'},back:{width:46,height:46,borderRadius:23,backgroundColor:'rgba(30,35,32,.58)',alignItems:'center',justifyContent:'center'},backText:{color:colors.white,fontSize:32,marginTop:-4},scanTitle:{color:colors.white,fontWeight:'900',fontSize:18},frame:{alignSelf:'center',width:'84%',aspectRatio:1.35,position:'relative',marginTop:100},corner:{position:'absolute',width:44,height:44,borderColor:colors.lime},tl:{left:0,top:0,borderTopWidth:5,borderLeftWidth:5,borderTopLeftRadius:18},tr:{right:0,top:0,borderTopWidth:5,borderRightWidth:5,borderTopRightRadius:18},bl:{left:0,bottom:0,borderBottomWidth:5,borderLeftWidth:5,borderBottomLeftRadius:18},br:{right:0,bottom:0,borderBottomWidth:5,borderRightWidth:5,borderBottomRightRadius:18},help:{alignSelf:'center',backgroundColor:'rgba(35,41,37,.72)',borderRadius:999,paddingVertical:13,paddingHorizontal:20,flexDirection:'row',gap:10,alignItems:'center'},helpText:{color:colors.white,fontSize:12,fontWeight:'700'}})
