import React,{useState} from 'react';
import {ActivityIndicator,Pressable,ScrollView,StyleSheet,Text,TextInput,View} from 'react-native';
import {useRouter} from 'expo-router';
import {ScreenHeader} from '@/components/ScreenHeader';
import {GlassCard} from '@/components/GlassCard';
import {OnlineFoodResult,searchPackagedFoods} from '@/services/openFoodFacts';
import {colors} from '@/theme/colors';

export default function OnlineFood(){
 const router=useRouter();const[q,setQ]=useState('');const[busy,setBusy]=useState(false);const[items,setItems]=useState<OnlineFoodResult[]>([]);const[msg,setMsg]=useState('Search sirf button press karne par chalegi taake free API rate limit waste na ho.');
 const search=async()=>{if(q.trim().length<2)return;try{setBusy(true);setMsg('');setItems(await searchPackagedFoods(q))}catch(e:any){setMsg(e?.message||'Search failed.')}finally{setBusy(false)}};
 return <ScrollView style={styles.screen} contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled"><ScreenHeader title="Online food search" subtitle="Free Open Food Facts database"/><View style={styles.searchRow}><TextInput value={q} onChangeText={setQ} placeholder="e.g. cereal, yogurt, biscuit" placeholderTextColor={colors.textDim} style={styles.input}/><Pressable style={styles.button} onPress={search}>{busy?<ActivityIndicator color={colors.dark}/>:<Text style={styles.buttonText}>Search</Text>}</Pressable></View>{msg?<Text style={styles.msg}>{msg}</Text>:null}{items.map((x,i)=><Pressable key={`${x.barcode}-${i}`} onPress={()=>router.replace({pathname:'/add-food',params:{product:JSON.stringify(x)}})}><GlassCard style={{marginTop:9}}><View style={styles.row}><View style={{flex:1}}><Text style={styles.name}>{x.name}</Text><Text style={styles.sub}>{x.servingLabel} · P {x.protein.toFixed(1)}g</Text></View><Text style={styles.cal}>{Math.round(x.calories)} kcal</Text></View></GlassCard></Pressable>)}</ScrollView>
}
const styles=StyleSheet.create({screen:{flex:1,backgroundColor:colors.bg},content:{paddingTop:54,paddingHorizontal:18,paddingBottom:44},searchRow:{flexDirection:'row',gap:9},input:{flex:1,height:54,borderRadius:27,paddingHorizontal:16,color:colors.white,backgroundColor:'rgba(39,45,41,.45)',borderWidth:1,borderColor:colors.border},button:{width:92,borderRadius:27,backgroundColor:colors.lime,alignItems:'center',justifyContent:'center'},buttonText:{color:colors.dark,fontWeight:'900'},msg:{color:colors.textDim,fontSize:10.5,lineHeight:16,textAlign:'center',marginTop:14},row:{padding:15,flexDirection:'row',alignItems:'center',gap:10},name:{color:colors.white,fontWeight:'900',fontSize:13.5},sub:{color:colors.textMuted,fontSize:10.5,marginTop:4},cal:{color:colors.lime,fontWeight:'900'}})
