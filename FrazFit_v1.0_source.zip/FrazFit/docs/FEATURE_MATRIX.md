# FrazFit feature matrix

| Feature | Status | Cost model |
|---|---|---|
| Local profile/goals | Implemented | Free/offline |
| Weight tracking | Implemented | Free/offline |
| Calories/macros | Implemented | Free/offline |
| Pakistani/common food library | Implemented | Free/offline |
| Custom food | Implemented | Free/offline |
| Barcode scanning | Implemented | Free/on-device scan |
| Barcode nutrition | Implemented | Free Open Food Facts API |
| Online packaged-food search | Implemented | Free Open Food Facts API |
| Food photo labeling | Implemented with confirmation flow | Free on-device ML Kit |
| Water | Implemented | Free/offline |
| Fasting | Implemented | Free/offline |
| Exercise library | Implemented | Free/offline |
| Exercise discovery | Implemented | Free public wger API |
| Automatic routine | Implemented | Free/local rules |
| 3D-style exercise motion guide | Implemented | Free/local |
| GPS walk tracking | Implemented | Free/device GPS |
| Measurements | Implemented | Free/offline |
| Progress photos | Implemented | Free/local storage |
| Backup/restore | Implemented | Free/local file |
| Paid APIs | None required | N/A |
| Login/account | Not included by design | N/A |
| Chatbot | Not included by design | N/A |
