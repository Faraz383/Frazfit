# FrazFit v1.0

FrazFit is a local-first personal fitness companion for Android. It is designed for lifetime use: nutrition, weight, walking, workouts, fasting, measurements and progress tracking without login, subscription or a paid API dependency.

## Design language

- Premium dark grey / muted sage base
- Neon-lime action color
- Rounded glass/depth cards
- 3D-style exercise figures and motion guides
- Clean health-tech dashboard inspired by the supplied visual reference, without copying proprietary assets

## Included features

### Dashboard
- Daily wellness score
- Calories eaten / remaining
- Protein and hydration progress
- Session step sensor
- Saved walking distance/time
- Workout minutes
- Weight-goal progress
- Quick actions

### Nutrition
- Built-in common/Pakistani starter food library
- Breakfast/lunch/snack/dinner logging
- Calories, protein, carbs and fat
- Quantity scaling
- Custom foods/recipes
- Barcode scanner using Expo Camera
- Free barcode nutrition lookup through Open Food Facts
- Explicit online packaged-food search to respect free API rate limits
- Food-photo flow using free on-device ML Kit image labeling where supported, with manual food/portion confirmation

### Training
- Local exercise library
- Free optional exercise discovery via the public wger API
- Auto-generated beginner/intermediate/advanced daily routine
- Weight/height-aware conservative load adjustment
- Morning and evening routine blocks
- Per-exercise timer, reps, sets and multi-set flow
- 3D-style pose-specific animated human guide
- Estimated exercise calorie burn
- Workout history

### Walking
- Foreground GPS walk tracking
- Distance, timer, pace and estimated calories
- Saved walk history
- No paid map provider required

### Progress
- Daily weight log and trend graph
- Start/current/target weight
- Waist, chest and arm measurements
- Private progress photos copied into local app storage

### Fasting
- 12h / 14h / 16h targets
- Persistent active timer
- Session history

### Local data / privacy
- No login
- No password
- No cloud account required
- SQLite database on-device
- JSON backup / restore
- Local notifications foundation

## Free external services

- Open Food Facts: barcode/product nutrition lookup
- wger: optional exercise discovery
- Google ML Kit image labeling: on-device, no per-request cloud bill

The core tracker remains useful offline. API-dependent discovery/scanning degrades gracefully when internet is unavailable.

## Tech stack

- Expo SDK 57
- React Native 0.86
- Expo Router
- Expo SQLite
- Expo Camera
- Expo Location
- Expo Sensors
- Expo Notifications
- Expo FileSystem / Sharing / DocumentPicker / ImagePicker
- `@react-native-ml-kit/image-labeling` for optional on-device food-photo labels

## Local build

This source package does not include `node_modules`.

```bash
npm install
npx expo prebuild
npx expo run:android --variant release
```

The ML Kit native module means the final app should be tested as a custom Android build rather than only in Expo Go.

## Release note

This source has been syntax-parsed across all TypeScript/TSX files. A real-device Android build is still the final validation step because this ChatGPT container currently does not contain the Android SDK/ADB toolchain or installed npm dependencies.

## Included GitHub APK workflow

`.github/workflows/android-apk.yml` is included. On a GitHub repository it installs dependencies, runs Expo prebuild, builds an installable Android debug APK, and uploads it as a workflow artifact. This gives a no-paid-API path to turn the source into a sideloadable APK once the repository can run GitHub Actions.
