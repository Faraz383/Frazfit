export const radius = {
  sm: 14,
  md: 22,
  lg: 30,
  xl: 40,
  pill: 999,
};

export const spacing = {
  xs: 6,
  sm: 10,
  md: 16,
  lg: 22,
  xl: 30,
};
