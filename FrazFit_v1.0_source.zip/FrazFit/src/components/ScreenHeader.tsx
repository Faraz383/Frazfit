import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import { colors } from '@/theme/colors';

export function ScreenHeader({title,subtitle,back=true,right}:{title:string;subtitle?:string;back?:boolean;right?:React.ReactNode}){
  const router=useRouter();
  return <View style={styles.row}>
    <View style={styles.left}>
      {back?<Pressable style={styles.back} onPress={()=>router.back()}><Text style={styles.backText}>‹</Text></Pressable>:null}
      <View style={{flex:1}}><Text style={styles.title}>{title}</Text>{subtitle?<Text style={styles.subtitle}>{subtitle}</Text>:null}</View>
    </View>
    {right || <View style={{width:44}}/>}
  </View>
}
const styles=StyleSheet.create({row:{flexDirection:'row',alignItems:'center',justifyContent:'space-between',gap:12,marginBottom:18},left:{flex:1,flexDirection:'row',alignItems:'center',gap:12},back:{width:44,height:44,borderRadius:22,backgroundColor:'rgba(32,38,34,.36)',borderWidth:1,borderColor:'rgba(255,255,255,.15)',alignItems:'center',justifyContent:'center'},backText:{color:colors.white,fontSize:31,marginTop:-4},title:{color:colors.white,fontSize:23,fontWeight:'900'},subtitle:{color:colors.textMuted,fontSize:10.5,marginTop:3}})
