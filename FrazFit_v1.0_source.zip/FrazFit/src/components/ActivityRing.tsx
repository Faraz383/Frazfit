import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { colors } from '@/theme/colors';

export function ActivityRing({value,label,size=112}:{value:number;label?:string;size?:number}){
  const pct=Math.max(0,Math.min(100,Math.round(value*100)));
  const inner=size-18;
  return <View style={[styles.outer,{width:size,height:size,borderRadius:size/2}]}>
    <View style={[styles.inner,{width:inner,height:inner,borderRadius:inner/2}]}>
      <Text style={styles.value}>{pct}%</Text>{label?<Text style={styles.label}>{label}</Text>:null}
    </View>
  </View>
}
const styles=StyleSheet.create({outer:{borderWidth:9,borderColor:colors.lime,backgroundColor:'rgba(183,255,0,.08)',alignItems:'center',justifyContent:'center',shadowColor:colors.lime,shadowOpacity:.2,shadowRadius:13,elevation:6},inner:{backgroundColor:'rgba(48,56,51,.84)',alignItems:'center',justifyContent:'center',borderWidth:1,borderColor:'rgba(255,255,255,.12)'},value:{color:colors.white,fontWeight:'900',fontSize:21},label:{color:colors.textMuted,fontSize:9,marginTop:2}})
