import React, { useEffect, useMemo, useRef } from 'react';
import { Animated, StyleSheet, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { colors } from '@/theme/colors';

type Pose = 'walk'|'squat'|'push'|'bridge'|'plank'|'row'|'core'|'mobility'|'standing';
function poseFor(name=''):Pose{
  const n=name.toLowerCase();
  if(n.includes('walk')||n.includes('march'))return 'walk';
  if(n.includes('squat')||n.includes('step-up'))return 'squat';
  if(n.includes('push'))return 'push';
  if(n.includes('bridge'))return 'bridge';
  if(n.includes('plank'))return 'plank';
  if(n.includes('row'))return 'row';
  if(n.includes('bird')||n.includes('dead bug'))return 'core';
  if(n.includes('cat')||n.includes('child'))return 'mobility';
  return 'standing';
}

export function ExerciseFigure({ active=false, exerciseName='' }:{active?:boolean;exerciseName?:string}){
  const motion=useRef(new Animated.Value(0)).current;
  const pose=useMemo(()=>poseFor(exerciseName),[exerciseName]);
  useEffect(()=>{
    if(!active){motion.stopAnimation();motion.setValue(0);return;}
    const loop=Animated.loop(Animated.sequence([
      Animated.timing(motion,{toValue:1,duration:650,useNativeDriver:true}),
      Animated.timing(motion,{toValue:0,duration:650,useNativeDriver:true}),
    ])); loop.start(); return()=>loop.stop();
  },[active,motion]);
  const bob=motion.interpolate({inputRange:[0,1],outputRange:[0,-8]});
  const swing=motion.interpolate({inputRange:[0,1],outputRange:['-16deg','18deg']});
  const squatY=motion.interpolate({inputRange:[0,1],outputRange:[0,32]});
  const tilt=pose==='push'||pose==='plank'||pose==='bridge'||pose==='core'||pose==='mobility'?'72deg':'0deg';
  const bodyMove=pose==='squat'?squatY:bob;
  return <View style={styles.stage}>
    <LinearGradient colors={['rgba(255,255,255,.10)','rgba(0,0,0,.06)']} style={StyleSheet.absoluteFill}/>
    <View style={styles.gridA}/><View style={styles.gridB}/>
    <Animated.View style={[styles.person,{transform:[{translateY:bodyMove},{rotate:tilt}]}]}>
      <LinearGradient colors={['#F0F4F1','#9CA59F']} style={styles.head}/>
      <LinearGradient colors={['#9FAAA3','#414943']} style={styles.torso}/>
      <Animated.View style={[styles.armLeft,{transform:[{rotate:pose==='row'?swing:pose==='walk'?swing:'-12deg'}]}]}/>
      <Animated.View style={[styles.armRight,{transform:[{rotate:pose==='walk'?swing:'14deg'}]}]}/>
      <Animated.View style={[styles.legLeft,{transform:[{rotate:pose==='walk'?swing:pose==='squat'?'28deg':'8deg'}]}]}/>
      <Animated.View style={[styles.legRight,{transform:[{rotate:pose==='walk'?swing:pose==='squat'?'-28deg':'-10deg'}]}]}/>
    </Animated.View>
    <View style={styles.glow}/>
    <View style={styles.poseTag}><View style={styles.dot}/></View>
  </View>
}

const styles=StyleSheet.create({stage:{height:276,borderRadius:36,overflow:'hidden',backgroundColor:'#68716C',borderWidth:1,borderColor:'rgba(255,255,255,.24)',alignItems:'center',justifyContent:'center'},gridA:{position:'absolute',width:450,height:1,backgroundColor:'rgba(255,255,255,.10)',transform:[{rotate:'18deg'}]},gridB:{position:'absolute',width:1,height:430,backgroundColor:'rgba(255,255,255,.08)',transform:[{rotate:'18deg'}]},person:{width:180,height:225,alignItems:'center',marginTop:18},head:{width:57,height:57,borderRadius:29,zIndex:3,borderWidth:1,borderColor:'rgba(255,255,255,.6)'},torso:{width:86,height:96,borderRadius:32,marginTop:-4,zIndex:2,borderWidth:1,borderColor:'rgba(255,255,255,.16)'},armLeft:{position:'absolute',width:27,height:98,borderRadius:18,backgroundColor:'#59635D',left:28,top:64,transformOrigin:'top center'},armRight:{position:'absolute',width:26,height:94,borderRadius:18,backgroundColor:'#737D76',right:28,top:64,transformOrigin:'top center'},legLeft:{position:'absolute',width:31,height:94,borderRadius:20,backgroundColor:'#303833',left:55,top:142,transformOrigin:'top center'},legRight:{position:'absolute',width:31,height:94,borderRadius:20,backgroundColor:'#414943',right:52,top:141,transformOrigin:'top center'},glow:{position:'absolute',bottom:17,width:150,height:28,borderRadius:75,backgroundColor:'rgba(183,255,0,.17)',transform:[{scaleX:1.7}]},poseTag:{position:'absolute',right:18,top:18,width:42,height:42,borderRadius:21,backgroundColor:'rgba(32,38,34,.44)',borderWidth:1,borderColor:'rgba(255,255,255,.18)',alignItems:'center',justifyContent:'center'},dot:{width:13,height:13,borderRadius:7,backgroundColor:colors.lime,shadowColor:colors.lime,shadowOpacity:.8,shadowRadius:7,elevation:5}})
