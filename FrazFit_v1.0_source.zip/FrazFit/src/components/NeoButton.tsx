import React from 'react';
import { Pressable, StyleSheet, Text, ViewStyle } from 'react-native';
import { colors } from '@/theme/colors';

export function NeoButton({label,onPress,secondary=false,style,disabled=false}:{label:string;onPress:()=>void;secondary?:boolean;style?:ViewStyle;disabled?:boolean}){
  return <Pressable disabled={disabled} onPress={onPress} style={({pressed})=>[
    styles.base,secondary?styles.secondary:styles.primary,style,pressed&&{opacity:.82},disabled&&{opacity:.45}
  ]}><Text style={[styles.text,secondary&&styles.secondaryText]}>{label}</Text></Pressable>
}
const styles=StyleSheet.create({base:{minHeight:52,borderRadius:999,alignItems:'center',justifyContent:'center',paddingHorizontal:18},primary:{backgroundColor:colors.lime,shadowColor:colors.lime,shadowOpacity:.28,shadowRadius:12,elevation:6},secondary:{backgroundColor:'rgba(35,42,38,.44)',borderWidth:1,borderColor:colors.border},text:{color:colors.dark,fontWeight:'900',fontSize:14},secondaryText:{color:colors.white}})
