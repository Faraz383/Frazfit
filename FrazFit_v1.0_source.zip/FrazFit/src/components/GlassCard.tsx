import React, { PropsWithChildren } from 'react';
import { StyleProp, StyleSheet, View, ViewStyle } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { colors } from '@/theme/colors';
import { radius } from '@/theme/layout';

type Props = PropsWithChildren<{
  style?: StyleProp<ViewStyle>;
  glow?: boolean;
}>;

export function GlassCard({ children, style, glow = false }: Props) {
  return (
    <View style={[styles.shadow, glow && styles.glowShadow, style]}>
      <LinearGradient
        colors={glow ? ['rgba(183,255,0,0.18)', 'rgba(255,255,255,0.10)'] : ['rgba(255,255,255,0.16)', 'rgba(25,31,27,0.17)']}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={styles.card}
      >
        <View style={styles.highlight} />
        {children}
      </LinearGradient>
    </View>
  );
}

const styles = StyleSheet.create({
  shadow: {
    borderRadius: radius.lg,
    shadowColor: '#1D211E',
    shadowOpacity: 0.32,
    shadowRadius: 18,
    shadowOffset: { width: 0, height: 12 },
    elevation: 10,
  },
  glowShadow: {
    shadowColor: colors.lime,
    shadowOpacity: 0.18,
  },
  card: {
    overflow: 'hidden',
    borderRadius: radius.lg,
    borderWidth: 1,
    borderColor: colors.border,
  },
  highlight: {
    position: 'absolute',
    top: 0,
    left: 24,
    right: 24,
    height: 1,
    backgroundColor: 'rgba(255,255,255,0.42)',
  },
});
