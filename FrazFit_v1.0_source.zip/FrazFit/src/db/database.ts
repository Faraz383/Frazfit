import * as SQLite from 'expo-sqlite';

export type Profile = {
  startWeight: number;
  currentWeight: number;
  targetWeight: number;
  heightCm: number;
  age: number;
  calorieGoal: number;
  proteinGoal: number;
  waterGoalMl: number;
  fitnessLevel: 'beginner' | 'intermediate' | 'advanced';
  dailyStepGoal: number;
};

export type Food = {
  id: number;
  name: string;
  servingLabel: string;
  servingGrams: number;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  category: string;
};

export type Exercise = {
  id: number;
  name: string;
  category: string;
  defaultSeconds: number;
  defaultReps: number;
  defaultSets: number;
  met: number;
  impact: 'low' | 'medium' | 'high';
  instructions: string;
};

export type DashboardSummary = {
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  waterMl: number;
  workoutMinutes: number;
  workoutCalories: number;
  walkKm: number;
  walkMinutes: number;
};

export type Measurement = {
  id: number;
  date: string;
  waistCm: number | null;
  chestCm: number | null;
  armCm: number | null;
};

export type FastSession = {
  id: number;
  startAt: string;
  endAt: string | null;
  targetHours: number;
};

export type WalkSession = {
  id: number;
  date: string;
  startedAt: string;
  endedAt: string;
  seconds: number;
  distanceM: number;
  caloriesBurned: number;
};

export type ProgressPhoto = {
  id: number;
  date: string;
  uri: string;
  note: string | null;
};

let dbPromise: Promise<SQLite.SQLiteDatabase> | null = null;

export function getDb() {
  if (!dbPromise) dbPromise = SQLite.openDatabaseAsync('frazfit.db');
  return dbPromise;
}

async function hasColumn(db: SQLite.SQLiteDatabase, table: string, column: string) {
  const rows = await db.getAllAsync<any>(`PRAGMA table_info(${table})`);
  return rows.some(r => r.name === column);
}

async function ensureColumn(db: SQLite.SQLiteDatabase, table: string, column: string, definition: string) {
  if (!(await hasColumn(db, table, column))) {
    await db.execAsync(`ALTER TABLE ${table} ADD COLUMN ${column} ${definition};`);
  }
}

export async function initDatabase() {
  const db = await getDb();
  await db.execAsync(`
    PRAGMA journal_mode = WAL;
    PRAGMA foreign_keys = ON;

    CREATE TABLE IF NOT EXISTS profile (
      id INTEGER PRIMARY KEY CHECK (id = 1),
      current_weight REAL NOT NULL,
      target_weight REAL NOT NULL,
      height_cm REAL NOT NULL,
      age INTEGER NOT NULL,
      calorie_goal INTEGER NOT NULL,
      protein_goal INTEGER NOT NULL,
      water_goal_ml INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS foods (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL UNIQUE,
      serving_label TEXT NOT NULL,
      serving_grams REAL NOT NULL,
      calories REAL NOT NULL,
      protein REAL NOT NULL,
      carbs REAL NOT NULL,
      fat REAL NOT NULL,
      category TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS food_entries (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      date TEXT NOT NULL,
      meal TEXT NOT NULL,
      name TEXT NOT NULL,
      quantity REAL NOT NULL,
      serving_label TEXT NOT NULL,
      calories REAL NOT NULL,
      protein REAL NOT NULL,
      carbs REAL NOT NULL,
      fat REAL NOT NULL,
      barcode TEXT,
      source TEXT NOT NULL DEFAULT 'local'
    );

    CREATE TABLE IF NOT EXISTS water_entries (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      date TEXT NOT NULL,
      ml INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS weight_entries (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      date TEXT NOT NULL UNIQUE,
      weight REAL NOT NULL
    );

    CREATE TABLE IF NOT EXISTS exercises (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL UNIQUE,
      category TEXT NOT NULL,
      default_seconds INTEGER NOT NULL,
      default_reps INTEGER NOT NULL,
      default_sets INTEGER NOT NULL,
      met REAL NOT NULL,
      impact TEXT NOT NULL,
      instructions TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS workout_sessions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      date TEXT NOT NULL,
      exercise_id INTEGER,
      exercise_name TEXT NOT NULL,
      seconds INTEGER NOT NULL,
      reps INTEGER NOT NULL,
      sets INTEGER NOT NULL,
      calories_burned REAL NOT NULL,
      FOREIGN KEY(exercise_id) REFERENCES exercises(id)
    );

    CREATE TABLE IF NOT EXISTS measurements (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      date TEXT NOT NULL,
      waist_cm REAL,
      chest_cm REAL,
      arm_cm REAL
    );

    CREATE TABLE IF NOT EXISTS fasting_sessions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      start_at TEXT NOT NULL,
      end_at TEXT,
      target_hours REAL NOT NULL DEFAULT 14
    );

    CREATE TABLE IF NOT EXISTS walk_sessions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      date TEXT NOT NULL,
      started_at TEXT NOT NULL,
      ended_at TEXT NOT NULL,
      seconds INTEGER NOT NULL,
      distance_m REAL NOT NULL,
      calories_burned REAL NOT NULL
    );

    CREATE TABLE IF NOT EXISTS progress_photos (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      date TEXT NOT NULL,
      uri TEXT NOT NULL,
      note TEXT
    );

    CREATE TABLE IF NOT EXISTS app_settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL
    );
  `);

  await ensureColumn(db, 'profile', 'start_weight', 'REAL NOT NULL DEFAULT 97');
  await ensureColumn(db, 'profile', 'fitness_level', `TEXT NOT NULL DEFAULT 'beginner'`);
  await ensureColumn(db, 'profile', 'daily_step_goal', 'INTEGER NOT NULL DEFAULT 7000');

  const profile = await db.getFirstAsync<{ count: number }>('SELECT COUNT(*) AS count FROM profile');
  if (!profile?.count) {
    await db.runAsync(
      `INSERT INTO profile (id,current_weight,target_weight,height_cm,age,calorie_goal,protein_goal,water_goal_ml,start_weight,fitness_level,daily_step_goal)
       VALUES (1,97,72,165,21,2100,100,3000,97,'beginner',7000)`
    );
  }

  const foodCount = await db.getFirstAsync<{ count: number }>('SELECT COUNT(*) AS count FROM foods');
  if (!foodCount?.count) await seedFoods(db);

  const exerciseCount = await db.getFirstAsync<{ count: number }>('SELECT COUNT(*) AS count FROM exercises');
  if (!exerciseCount?.count) await seedExercises(db);
}

async function seedFoods(db: SQLite.SQLiteDatabase) {
  const foods = [
    ['Boiled egg','1 egg',50,78,6.3,0.6,5.3,'protein'],
    ['Omelette, 2 eggs + little oil','1 serving',120,210,13,2,16,'protein'],
    ['Plain dahi','100 g',100,61,3.5,4.7,3.3,'dairy'],
    ['Whole milk','250 ml',250,153,7.9,12,8,'dairy'],
    ['Low-fat milk','250 ml',250,105,8.5,12,2.5,'dairy'],
    ['Roti','1 medium',50,130,4,24,2.5,'grain'],
    ['Cooked daal','1 cup',200,230,16,40,1,'legume'],
    ['Boiled chana','1 cup',164,269,14.5,45,4.3,'legume'],
    ['Bhuna chana','30 g',30,120,6,18,2,'snack'],
    ['Peanuts','30 g',30,170,7.3,5,14.5,'nuts'],
    ['Almonds','30 g',30,174,6.4,6.5,15,'nuts'],
    ['Pistachios','30 g',30,168,6.1,8.4,13.5,'nuts'],
    ['Walnuts','30 g',30,196,4.6,4.1,19.6,'nuts'],
    ['Chicken breast cooked','100 g',100,165,31,0,3.6,'protein'],
    ['Chicken curry, home style estimate','1 bowl',220,320,28,10,18,'meal'],
    ['Apple','1 medium',182,95,0.5,25,0.3,'fruit'],
    ['Banana','1 medium',118,105,1.3,27,0.4,'fruit'],
    ['Cucumber','100 g',100,15,0.7,3.6,0.1,'vegetable'],
    ['Tomato','100 g',100,18,0.9,3.9,0.2,'vegetable'],
    ['Onion','100 g',100,40,1.1,9.3,0.1,'vegetable'],
    ['Mixed salad','1 bowl',200,55,2.3,12,0.5,'vegetable'],
    ['Cooked white rice','1 cup',158,205,4.3,45,0.4,'grain'],
    ['Chicken biryani (estimate)','1 plate',300,540,24,66,20,'meal'],
    ['Chana pulao (estimate)','1 plate',300,480,15,80,11,'meal'],
    ['Date','1 date',24,66,0.4,18,0.1,'fruit'],
    ['Black tea, no sugar','1 cup',240,2,0,0.5,0,'drink'],
    ['Milk tea, low sugar estimate','1 cup',180,65,2.5,9,2.5,'drink'],
  ];
  for (const row of foods) {
    await db.runAsync(
      `INSERT OR IGNORE INTO foods (name,serving_label,serving_grams,calories,protein,carbs,fat,category)
       VALUES (?,?,?,?,?,?,?,?)`, row as any
    );
  }
}

async function seedExercises(db: SQLite.SQLiteDatabase) {
  const rows = [
    ['Brisk walk','Cardio',1800,0,1,4.3,'low','Walk tall at a pace where breathing is faster but you can still speak in short sentences.'],
    ['Chair squat','Lower body',40,10,2,3.5,'low','Sit back toward a stable chair, keep knees tracking over feet, then stand tall.'],
    ['Wall push-up','Upper body',40,10,2,3.0,'low','Hands on wall at chest height. Keep body straight and lower chest toward the wall.'],
    ['Glute bridge','Lower body',40,12,2,3.0,'low','Lie on your back, knees bent, squeeze glutes and lift hips without over-arching the back.'],
    ['Bird dog','Core',40,8,2,2.8,'low','From hands and knees, extend opposite arm and leg while keeping hips stable.'],
    ['Dead bug','Core',40,8,2,2.8,'low','Lie on your back, brace your core and slowly lower opposite arm and leg.'],
    ['Standing calf raise','Lower body',40,12,2,3.0,'low','Hold a stable surface, rise onto the balls of your feet, pause, then lower slowly.'],
    ['Incline push-up','Upper body',40,8,2,3.8,'medium','Hands on a sturdy elevated surface. Keep a straight line from head to heels.'],
    ['Backpack row','Upper body',45,10,2,4.0,'medium','Hinge at hips with neutral back and pull a loaded backpack toward your ribs.'],
    ['Knee plank','Core',30,0,2,3.0,'low','Forearms and knees on the floor, brace your trunk and keep hips in line with shoulders.'],
    ['Step-up','Lower body',45,8,2,4.5,'medium','Use a low stable step. Step up under control, stand tall, then step down softly.'],
    ['Standing march','Cardio',60,0,2,3.5,'low','March in place, keep torso upright and move arms naturally.'],
    ['Side leg raise','Lower body',40,10,2,3.0,'low','Hold support, keep torso tall and lift one leg sideways without leaning.'],
    ['Shoulder press, light weight','Upper body',45,10,2,3.5,'medium','Press light weights overhead without arching your lower back.'],
    ['Biceps curl, light weight','Upper body',45,10,2,3.0,'low','Keep elbows close to your sides and curl the weight without swinging.'],
    ['Cat-cow mobility','Mobility',60,0,1,2.0,'low','On hands and knees, slowly alternate between a rounded and gently arched spine.'],
    ['Child pose breathing','Mobility',60,0,1,1.5,'low','Sit hips back toward heels, reach arms forward and breathe slowly.'],
  ];
  for (const row of rows) {
    await db.runAsync(
      `INSERT OR IGNORE INTO exercises (name,category,default_seconds,default_reps,default_sets,met,impact,instructions)
       VALUES (?,?,?,?,?,?,?,?)`, row as any
    );
  }
}

export function todayKey() {
  const d = new Date();
  const y = d.getFullYear();
  const m = String(d.getMonth()+1).padStart(2,'0');
  const day = String(d.getDate()).padStart(2,'0');
  return `${y}-${m}-${day}`;
}

export async function getProfile(): Promise<Profile> {
  const db = await getDb();
  const r = await db.getFirstAsync<any>('SELECT * FROM profile WHERE id=1');
  return {
    startWeight: Number(r.start_weight ?? r.current_weight),
    currentWeight: Number(r.current_weight),
    targetWeight: Number(r.target_weight),
    heightCm: Number(r.height_cm),
    age: Number(r.age),
    calorieGoal: Number(r.calorie_goal),
    proteinGoal: Number(r.protein_goal),
    waterGoalMl: Number(r.water_goal_ml),
    fitnessLevel: (r.fitness_level || 'beginner') as Profile['fitnessLevel'],
    dailyStepGoal: Number(r.daily_step_goal || 7000),
  };
}

export async function updateProfile(p: Partial<Profile>) {
  const current = await getProfile();
  const next = { ...current, ...p };
  const db = await getDb();
  await db.runAsync(
    `UPDATE profile SET current_weight=?,target_weight=?,height_cm=?,age=?,calorie_goal=?,protein_goal=?,water_goal_ml=?,start_weight=?,fitness_level=?,daily_step_goal=? WHERE id=1`,
    next.currentWeight,next.targetWeight,next.heightCm,next.age,next.calorieGoal,next.proteinGoal,next.waterGoalMl,
    next.startWeight,next.fitnessLevel,next.dailyStepGoal
  );
}

export async function getFoods(query = ''): Promise<Food[]> {
  const db = await getDb();
  const rows = query.trim()
    ? await db.getAllAsync<any>('SELECT * FROM foods WHERE name LIKE ? ORDER BY name LIMIT 100', `%${query.trim()}%`)
    : await db.getAllAsync<any>('SELECT * FROM foods ORDER BY category,name LIMIT 100');
  return rows.map(r => ({
    id:r.id,name:r.name,servingLabel:r.serving_label,servingGrams:r.serving_grams,
    calories:Number(r.calories),protein:Number(r.protein),carbs:Number(r.carbs),fat:Number(r.fat),category:r.category
  }));
}

export async function addCustomFood(input: Omit<Food,'id'>) {
  const db = await getDb();
  await db.runAsync(
    `INSERT INTO foods (name,serving_label,serving_grams,calories,protein,carbs,fat,category)
     VALUES (?,?,?,?,?,?,?,?)
     ON CONFLICT(name) DO UPDATE SET serving_label=excluded.serving_label,serving_grams=excluded.serving_grams,calories=excluded.calories,protein=excluded.protein,carbs=excluded.carbs,fat=excluded.fat,category=excluded.category`,
    input.name,input.servingLabel,input.servingGrams,input.calories,input.protein,input.carbs,input.fat,input.category
  );
}

export async function addFoodEntry(input: {
  meal: string; name: string; quantity: number; servingLabel: string;
  calories: number; protein: number; carbs: number; fat: number;
  barcode?: string; source?: string;
}) {
  const db = await getDb();
  const q = input.quantity;
  await db.runAsync(
    `INSERT INTO food_entries (date,meal,name,quantity,serving_label,calories,protein,carbs,fat,barcode,source)
     VALUES (?,?,?,?,?,?,?,?,?,?,?)`,
    todayKey(), input.meal, input.name, q, input.servingLabel,
    input.calories*q, input.protein*q, input.carbs*q, input.fat*q,
    input.barcode ?? null, input.source ?? 'local'
  );
}

export async function getTodayFoodEntries() {
  const db = await getDb();
  return db.getAllAsync<any>('SELECT * FROM food_entries WHERE date=? ORDER BY id DESC', todayKey());
}

export async function deleteFoodEntry(id: number) {
  const db = await getDb();
  await db.runAsync('DELETE FROM food_entries WHERE id=?', id);
}

export async function addWater(ml: number) {
  const db = await getDb();
  await db.runAsync('INSERT INTO water_entries (date,ml) VALUES (?,?)', todayKey(), ml);
}

export async function removeLastWaterEntry() {
  const db = await getDb();
  const last = await db.getFirstAsync<{id:number}>('SELECT id FROM water_entries WHERE date=? ORDER BY id DESC LIMIT 1', todayKey());
  if (last?.id) await db.runAsync('DELETE FROM water_entries WHERE id=?', last.id);
}

export async function getDashboardSummary(): Promise<DashboardSummary> {
  const db = await getDb();
  const food = await db.getFirstAsync<any>(`SELECT
      COALESCE(SUM(calories),0) AS calories,
      COALESCE(SUM(protein),0) AS protein,
      COALESCE(SUM(carbs),0) AS carbs,
      COALESCE(SUM(fat),0) AS fat
    FROM food_entries WHERE date=?`, todayKey());
  const water = await db.getFirstAsync<any>('SELECT COALESCE(SUM(ml),0) AS ml FROM water_entries WHERE date=?', todayKey());
  const workout = await db.getFirstAsync<any>('SELECT COALESCE(SUM(seconds),0) AS seconds, COALESCE(SUM(calories_burned),0) AS calories FROM workout_sessions WHERE date=?', todayKey());
  const walk = await db.getFirstAsync<any>('SELECT COALESCE(SUM(seconds),0) AS seconds, COALESCE(SUM(distance_m),0) AS distance_m FROM walk_sessions WHERE date=?', todayKey());
  return {
    calories: Number(food?.calories || 0), protein: Number(food?.protein || 0),
    carbs: Number(food?.carbs || 0), fat: Number(food?.fat || 0),
    waterMl: Number(water?.ml || 0), workoutMinutes: Math.round(Number(workout?.seconds || 0)/60),
    workoutCalories: Number(workout?.calories || 0), walkKm: Number(walk?.distance_m || 0)/1000,
    walkMinutes: Math.round(Number(walk?.seconds || 0)/60),
  };
}

export async function getExercises(): Promise<Exercise[]> {
  const db = await getDb();
  const rows = await db.getAllAsync<any>('SELECT * FROM exercises ORDER BY category,name');
  return rows.map(r => ({
    id:r.id,name:r.name,category:r.category,defaultSeconds:r.default_seconds,
    defaultReps:r.default_reps,defaultSets:r.default_sets,met:Number(r.met),impact:r.impact,
    instructions:r.instructions
  }));
}

export async function getExercise(id: number): Promise<Exercise | null> {
  const db = await getDb();
  const r = await db.getFirstAsync<any>('SELECT * FROM exercises WHERE id=?', id);
  if (!r) return null;
  return { id:r.id,name:r.name,category:r.category,defaultSeconds:r.default_seconds,defaultReps:r.default_reps,defaultSets:r.default_sets,met:Number(r.met),impact:r.impact,instructions:r.instructions };
}

export async function completeExercise(exercise: Exercise, seconds: number, reps: number, sets: number) {
  const profile = await getProfile();
  const activeSeconds = Math.max(seconds, exercise.defaultSeconds) * Math.max(1, sets);
  const minutes = Math.max(1/6, activeSeconds / 60);
  const calories = exercise.met * 3.5 * profile.currentWeight / 200 * minutes;
  const db = await getDb();
  await db.runAsync(
    `INSERT INTO workout_sessions (date,exercise_id,exercise_name,seconds,reps,sets,calories_burned)
     VALUES (?,?,?,?,?,?,?)`,
    todayKey(),exercise.id,exercise.name,activeSeconds,reps,sets,calories
  );
  return calories;
}

export async function getWorkoutHistory(limit = 40) {
  const db = await getDb();
  return db.getAllAsync<any>('SELECT * FROM workout_sessions ORDER BY id DESC LIMIT ?', limit);
}

export async function addWeight(weight: number) {
  const db = await getDb();
  await db.runAsync(`INSERT INTO weight_entries (date,weight) VALUES (?,?)
    ON CONFLICT(date) DO UPDATE SET weight=excluded.weight`, todayKey(), weight);
  await updateProfile({ currentWeight: weight });
}

export async function getWeightHistory(limit = 60) {
  const db = await getDb();
  return db.getAllAsync<{date:string;weight:number}>(
    'SELECT date,weight FROM weight_entries ORDER BY date DESC LIMIT ?', limit
  );
}

export async function addMeasurement(input: { waistCm?: number; chestCm?: number; armCm?: number }) {
  const db = await getDb();
  await db.runAsync(
    `INSERT INTO measurements (date,waist_cm,chest_cm,arm_cm) VALUES (?,?,?,?)`,
    todayKey(), input.waistCm ?? null, input.chestCm ?? null, input.armCm ?? null
  );
}

export async function getMeasurementHistory(limit = 30): Promise<Measurement[]> {
  const db = await getDb();
  const rows = await db.getAllAsync<any>('SELECT * FROM measurements ORDER BY id DESC LIMIT ?', limit);
  return rows.map(r => ({id:r.id,date:r.date,waistCm:r.waist_cm,chestCm:r.chest_cm,armCm:r.arm_cm}));
}

export async function startFast(targetHours = 14) {
  const active = await getActiveFast();
  if (active) return active;
  const db = await getDb();
  const started = new Date().toISOString();
  const result = await db.runAsync('INSERT INTO fasting_sessions (start_at,target_hours) VALUES (?,?)', started, targetHours);
  return { id:Number(result.lastInsertRowId), startAt:started, endAt:null, targetHours } as FastSession;
}

export async function getActiveFast(): Promise<FastSession | null> {
  const db = await getDb();
  const r = await db.getFirstAsync<any>('SELECT * FROM fasting_sessions WHERE end_at IS NULL ORDER BY id DESC LIMIT 1');
  return r ? {id:r.id,startAt:r.start_at,endAt:r.end_at,targetHours:Number(r.target_hours)} : null;
}

export async function endFast() {
  const active = await getActiveFast();
  if (!active) return null;
  const endAt = new Date().toISOString();
  const db = await getDb();
  await db.runAsync('UPDATE fasting_sessions SET end_at=? WHERE id=?', endAt, active.id);
  return {...active,endAt};
}

export async function getFastingHistory(limit = 20): Promise<FastSession[]> {
  const db = await getDb();
  const rows = await db.getAllAsync<any>('SELECT * FROM fasting_sessions ORDER BY id DESC LIMIT ?', limit);
  return rows.map(r => ({id:r.id,startAt:r.start_at,endAt:r.end_at,targetHours:Number(r.target_hours)}));
}

export async function addWalkSession(input: { startedAt:string; endedAt:string; seconds:number; distanceM:number; caloriesBurned:number }) {
  const db = await getDb();
  await db.runAsync(
    'INSERT INTO walk_sessions (date,started_at,ended_at,seconds,distance_m,calories_burned) VALUES (?,?,?,?,?,?)',
    todayKey(),input.startedAt,input.endedAt,input.seconds,input.distanceM,input.caloriesBurned
  );
}

export async function getWalkHistory(limit = 30): Promise<WalkSession[]> {
  const db = await getDb();
  const rows = await db.getAllAsync<any>('SELECT * FROM walk_sessions ORDER BY id DESC LIMIT ?',limit);
  return rows.map(r=>({id:r.id,date:r.date,startedAt:r.started_at,endedAt:r.ended_at,seconds:Number(r.seconds),distanceM:Number(r.distance_m),caloriesBurned:Number(r.calories_burned)}));
}

export async function addProgressPhoto(uri: string, note = '') {
  const db = await getDb();
  await db.runAsync('INSERT INTO progress_photos (date,uri,note) VALUES (?,?,?)',todayKey(),uri,note || null);
}

export async function getProgressPhotos(limit = 60): Promise<ProgressPhoto[]> {
  const db = await getDb();
  const rows = await db.getAllAsync<any>('SELECT * FROM progress_photos ORDER BY id DESC LIMIT ?',limit);
  return rows.map(r=>({id:r.id,date:r.date,uri:r.uri,note:r.note}));
}

export async function deleteProgressPhoto(id:number) {
  const db = await getDb();
  await db.runAsync('DELETE FROM progress_photos WHERE id=?',id);
}

export async function setSetting(key:string,value:string) {
  const db = await getDb();
  await db.runAsync(`INSERT INTO app_settings (key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value`,key,value);
}

export async function getSetting(key:string, fallback = '') {
  const db = await getDb();
  const r = await db.getFirstAsync<{value:string}>('SELECT value FROM app_settings WHERE key=?',key);
  return r?.value ?? fallback;
}

export async function exportAllData() {
  const db = await getDb();
  const tables = ['profile','foods','food_entries','water_entries','weight_entries','exercises','workout_sessions','measurements','fasting_sessions','walk_sessions','progress_photos','app_settings'];
  const data: Record<string, any[]> = {};
  for (const table of tables) data[table] = await db.getAllAsync(`SELECT * FROM ${table}`);
  return { app: 'FrazFit', version: 2, exportedAt: new Date().toISOString(), data };
}

export async function restoreAllData(payload: any) {
  if (!payload || payload.app !== 'FrazFit' || !payload.data) throw new Error('Invalid FrazFit backup file.');
  const db = await getDb();
  await db.execAsync('BEGIN TRANSACTION;');
  try {
    const ordered = ['food_entries','water_entries','weight_entries','workout_sessions','measurements','fasting_sessions','walk_sessions','progress_photos','app_settings','profile','foods','exercises'];
    for (const table of ordered) await db.execAsync(`DELETE FROM ${table};`);
    const d = payload.data;
    for (const r of d.profile || []) await db.runAsync(
      `INSERT INTO profile (id,current_weight,target_weight,height_cm,age,calorie_goal,protein_goal,water_goal_ml,start_weight,fitness_level,daily_step_goal) VALUES (?,?,?,?,?,?,?,?,?,?,?)`,
      r.id,r.current_weight,r.target_weight,r.height_cm,r.age,r.calorie_goal,r.protein_goal,r.water_goal_ml,r.start_weight ?? r.current_weight,r.fitness_level ?? 'beginner',r.daily_step_goal ?? 7000
    );
    for (const r of d.foods || []) await db.runAsync('INSERT INTO foods VALUES (?,?,?,?,?,?,?,?,?)',r.id,r.name,r.serving_label,r.serving_grams,r.calories,r.protein,r.carbs,r.fat,r.category);
    for (const r of d.exercises || []) await db.runAsync('INSERT INTO exercises VALUES (?,?,?,?,?,?,?,?,?)',r.id,r.name,r.category,r.default_seconds,r.default_reps,r.default_sets,r.met,r.impact,r.instructions);
    for (const r of d.food_entries || []) await db.runAsync('INSERT INTO food_entries VALUES (?,?,?,?,?,?,?,?,?,?,?,?)',r.id,r.date,r.meal,r.name,r.quantity,r.serving_label,r.calories,r.protein,r.carbs,r.fat,r.barcode,r.source);
    for (const r of d.water_entries || []) await db.runAsync('INSERT INTO water_entries VALUES (?,?,?)',r.id,r.date,r.ml);
    for (const r of d.weight_entries || []) await db.runAsync('INSERT INTO weight_entries VALUES (?,?,?)',r.id,r.date,r.weight);
    for (const r of d.workout_sessions || []) await db.runAsync('INSERT INTO workout_sessions VALUES (?,?,?,?,?,?,?,?)',r.id,r.date,r.exercise_id,r.exercise_name,r.seconds,r.reps,r.sets,r.calories_burned);
    for (const r of d.measurements || []) await db.runAsync('INSERT INTO measurements VALUES (?,?,?,?,?)',r.id,r.date,r.waist_cm,r.chest_cm,r.arm_cm);
    for (const r of d.fasting_sessions || []) await db.runAsync('INSERT INTO fasting_sessions VALUES (?,?,?,?)',r.id,r.start_at,r.end_at,r.target_hours);
    for (const r of d.walk_sessions || []) await db.runAsync('INSERT INTO walk_sessions VALUES (?,?,?,?,?,?,?)',r.id,r.date,r.started_at,r.ended_at,r.seconds,r.distance_m,r.calories_burned);
    for (const r of d.progress_photos || []) await db.runAsync('INSERT INTO progress_photos VALUES (?,?,?,?)',r.id,r.date,r.uri,r.note);
    for (const r of d.app_settings || []) await db.runAsync('INSERT INTO app_settings VALUES (?,?)',r.key,r.value);
    await db.execAsync('COMMIT;');
  } catch (e) {
    await db.execAsync('ROLLBACK;');
    throw e;
  }
}

export async function addDiscoveredExercise(input:{name:string;category:string;instructions:string}) {
  const db=await getDb();
  await db.runAsync(
    `INSERT INTO exercises (name,category,default_seconds,default_reps,default_sets,met,impact,instructions)
     VALUES (?,?,?,?,?,?,?,?)
     ON CONFLICT(name) DO UPDATE SET category=excluded.category,instructions=CASE WHEN excluded.instructions<>'' THEN excluded.instructions ELSE exercises.instructions END`,
    input.name,input.category||'Exercise',40,10,2,3.5,'low',input.instructions||'Use controlled form and stop if you feel pain.'
  );
}
