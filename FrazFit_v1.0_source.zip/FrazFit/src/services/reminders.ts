import * as Notifications from 'expo-notifications';
import { Platform } from 'react-native';

export async function prepareNotifications() {
  if (Platform.OS === 'android') {
    await Notifications.setNotificationChannelAsync('frazfit-reminders', {
      name: 'FrazFit reminders',
      importance: Notifications.AndroidImportance.DEFAULT,
    });
  }
  const existing = await Notifications.getPermissionsAsync();
  if (!existing.granted) await Notifications.requestPermissionsAsync();
}

async function scheduleDaily(title:string,body:string,hour:number,minute:number) {
  await prepareNotifications();
  return Notifications.scheduleNotificationAsync({
    content:{title,body},
    trigger:{type:Notifications.SchedulableTriggerInputTypes.DAILY,hour,minute,channelId:'frazfit-reminders'} as any,
  });
}

export const scheduleDailyWaterReminder=(hour=10,minute=0)=>scheduleDaily('Hydration check','Add your latest water intake in FrazFit.',hour,minute);
export const scheduleDailyWeightReminder=(hour=7,minute=0)=>scheduleDaily('Morning weigh-in','If today is a weigh-in day, log your weight before breakfast.',hour,minute);
export const scheduleDailyWorkoutReminder=(hour=18,minute=0)=>scheduleDaily('Movement check','Open your FrazFit workout plan or take a walk.',hour,minute);

export async function cancelAllFrazFitReminders(){
  await Notifications.cancelAllScheduledNotificationsAsync();
}
