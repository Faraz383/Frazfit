export type LatLng = { latitude:number; longitude:number };

export function haversineMeters(a:LatLng,b:LatLng) {
  const R = 6371000;
  const toRad = (d:number) => d*Math.PI/180;
  const dLat = toRad(b.latitude-a.latitude);
  const dLon = toRad(b.longitude-a.longitude);
  const lat1 = toRad(a.latitude);
  const lat2 = toRad(b.latitude);
  const h = Math.sin(dLat/2)**2 + Math.cos(lat1)*Math.cos(lat2)*Math.sin(dLon/2)**2;
  return 2*R*Math.asin(Math.sqrt(h));
}

export function estimateWalkingCalories(weightKg:number, seconds:number, brisk = true) {
  const met = brisk ? 4.3 : 3.3;
  return met*3.5*weightKg/200*(seconds/60);
}
