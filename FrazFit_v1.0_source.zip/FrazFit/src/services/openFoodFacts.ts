export type ScannedProduct = {
  name: string;
  servingLabel: string;
  servingGrams: number;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  barcode: string;
};

export type OnlineFoodResult = ScannedProduct & { barcode:string };

function number(v: unknown) {
  const n = Number(v);
  return Number.isFinite(n) ? n : 0;
}

function mapProduct(p:any, barcode = ''): ScannedProduct | null {
  if (!p) return null;
  const n = p.nutriments || {};
  const servingGrams = number(p.serving_quantity) || 100;
  const per100Multiplier = servingGrams / 100;
  const kcal100 = number(n['energy-kcal_100g'] ?? n['energy-kcal']);
  const protein100 = number(n.proteins_100g ?? n.proteins);
  const carbs100 = number(n.carbohydrates_100g ?? n.carbohydrates);
  const fat100 = number(n.fat_100g ?? n.fat);
  const code = String(barcode || p.code || '');
  return {
    name: p.product_name_en || p.product_name || `Product ${code || 'unknown'}`,
    servingLabel: p.serving_size || `${servingGrams} g`,
    servingGrams,
    calories: kcal100 * per100Multiplier,
    protein: protein100 * per100Multiplier,
    carbs: carbs100 * per100Multiplier,
    fat: fat100 * per100Multiplier,
    barcode: code,
  };
}

export async function lookupBarcode(barcode: string): Promise<ScannedProduct | null> {
  const fields = ['code','product_name','product_name_en','serving_size','serving_quantity','nutriments'].join(',');
  const url = `https://world.openfoodfacts.org/api/v2/product/${encodeURIComponent(barcode)}.json?fields=${fields}`;
  const res = await fetch(url, { headers: { 'User-Agent': 'FrazFit/1.0 (personal fitness app)' } });
  if (!res.ok) throw new Error(`Food database error (${res.status})`);
  const json = await res.json();
  return mapProduct(json?.product, barcode);
}

export async function searchPackagedFoods(query:string): Promise<OnlineFoodResult[]> {
  const q = query.trim();
  if (q.length < 2) return [];
  const fields = ['code','product_name','product_name_en','serving_size','serving_quantity','nutriments'].join(',');
  const url = `https://world.openfoodfacts.org/cgi/search.pl?search_terms=${encodeURIComponent(q)}&search_simple=1&action=process&json=1&page_size=12&fields=${fields}`;
  const res = await fetch(url,{headers:{'User-Agent':'FrazFit/1.0 (personal fitness app)'}});
  if (!res.ok) throw new Error(`Food search error (${res.status})`);
  const json = await res.json();
  return (json?.products || []).map((p:any)=>mapProduct(p)).filter(Boolean) as OnlineFoodResult[];
}
