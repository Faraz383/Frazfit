import * as FileSystem from 'expo-file-system/legacy';
import * as Sharing from 'expo-sharing';
import * as DocumentPicker from 'expo-document-picker';
import { exportAllData, restoreAllData } from '@/db/database';

export async function createBackup() {
  const payload = await exportAllData();
  const file = `${FileSystem.cacheDirectory}FrazFit-backup-${new Date().toISOString().slice(0,10)}.json`;
  await FileSystem.writeAsStringAsync(file, JSON.stringify(payload, null, 2));
  if (await Sharing.isAvailableAsync()) {
    await Sharing.shareAsync(file, {
      mimeType: 'application/json',
      dialogTitle: 'Save FrazFit backup',
    });
  }
  return file;
}

export async function restoreBackup() {
  const picked = await DocumentPicker.getDocumentAsync({ type: 'application/json', copyToCacheDirectory: true });
  if (picked.canceled) return false;
  const text = await FileSystem.readAsStringAsync(picked.assets[0].uri);
  const payload = JSON.parse(text);
  await restoreAllData(payload);
  return true;
}
