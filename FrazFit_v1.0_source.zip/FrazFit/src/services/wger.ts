export type WgerExercise = {
  id: number;
  name: string;
  category: string;
  description: string;
  imageUrl?: string;
};

function stripHtml(value:string) {
  return value.replace(/<[^>]*>/g,' ').replace(/\s+/g,' ').trim();
}

export async function fetchFreeExercises(limit = 30): Promise<WgerExercise[]> {
  const url = `https://wger.de/api/v2/exerciseinfo/?limit=${Math.min(50,Math.max(1,limit))}&language=2`;
  const res = await fetch(url,{headers:{Accept:'application/json'}});
  if (!res.ok) throw new Error(`Exercise database error (${res.status})`);
  const json = await res.json();
  return (json?.results || []).map((item:any) => {
    const translation = (item.translations || []).find((t:any)=>t.language===2) || (item.translations || [])[0] || {};
    const image = (item.images || []).find((i:any)=>i.is_main) || (item.images || [])[0];
    return {
      id:item.id,
      name:translation.name || item.name || `Exercise ${item.id}`,
      category:item.category?.name || 'Exercise',
      description:stripHtml(translation.description || ''),
      imageUrl:image?.image || undefined,
    };
  }).filter((e:WgerExercise)=>e.name);
}
