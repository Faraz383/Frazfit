import { Exercise, Profile } from '@/db/database';

export type PlannedExercise = Exercise & {
  recommendedReps: number;
  recommendedSets: number;
  recommendedSeconds: number;
};

export type WorkoutPlan = {
  title: string;
  subtitle: string;
  morning: PlannedExercise[];
  evening: PlannedExercise[];
};

function intensityFactor(profile: Profile) {
  if (profile.fitnessLevel === 'advanced') return 1.25;
  if (profile.fitnessLevel === 'intermediate') return 1.1;
  return 1;
}

function weightSafetyFactor(profile: Profile) {
  const bmi = profile.currentWeight / Math.pow(profile.heightCm / 100, 2);
  if (bmi >= 35) return 0.85;
  if (bmi >= 30) return 0.92;
  return 1;
}

function adapt(e: Exercise, profile: Profile): PlannedExercise {
  const factor = intensityFactor(profile) * weightSafetyFactor(profile);
  const reps = e.defaultReps > 0 ? Math.max(6, Math.round(e.defaultReps * factor)) : 0;
  const seconds = Math.max(20, Math.round(e.defaultSeconds * factor));
  const sets = Math.max(1, Math.round(e.defaultSets * (profile.fitnessLevel === 'advanced' ? 1.35 : 1)));
  return {...e,recommendedReps:reps,recommendedSets:sets,recommendedSeconds:seconds};
}

export function buildDailyWorkoutPlan(profile: Profile, exercises: Exercise[]): WorkoutPlan {
  const by = (name:string) => exercises.find(e => e.name === name);
  const compact = (arr:(Exercise|undefined)[]) => arr.filter(Boolean).map(e => adapt(e as Exercise,profile));
  const bmi = profile.currentWeight / Math.pow(profile.heightCm / 100,2);
  const highLoad = bmi >= 35;

  const morning = compact([
    by('Brisk walk'),
    by('Chair squat'),
    by(highLoad ? 'Wall push-up' : 'Incline push-up'),
    by('Backpack row'),
    by('Glute bridge'),
    by('Knee plank'),
  ]);

  const evening = compact([
    by('Standing march'),
    by('Bird dog'),
    by('Side leg raise'),
    by('Standing calf raise'),
    by('Cat-cow mobility'),
    by('Child pose breathing'),
  ]);

  return {
    title: highLoad ? 'Joint-friendly foundation' : 'Balanced fitness foundation',
    subtitle: 'Auto-generated from your current weight, height and selected fitness level. You can still edit every timer, set and rep.',
    morning,
    evening,
  };
}
